public class MamalesImpl extends Mamales {
    protected MamalesImpl(int i) {
        super(i);

    }
}
