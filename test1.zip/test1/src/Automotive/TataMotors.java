package Automotive;

public abstract class TataMotors {
    public int Capital;
    int Revinue;
    public abstract void Production();
    public void PlantHead(){
        double PlantHeadId;

    }
}
