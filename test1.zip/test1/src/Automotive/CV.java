package Automotive;

public class CV extends TataMotors{

    @Override
    public void Production() {

    }

    @Override
    public void PlantHead() {
        super.PlantHead();
    }
}
