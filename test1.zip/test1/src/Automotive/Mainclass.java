package Automotive;

public class Mainclass {
    public static void main(String[] args){
       PV pv= new PV();
       pv.PlantHead();
       Safari safari = new Safari("A", 5000000000000.45);
       safari.run();
    }

}
