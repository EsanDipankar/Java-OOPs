package Automotive;

public class EV extends TataMotors {

    @Override
    public void Production() {

    }

    @Override
    public void PlantHead() {
        super.PlantHead();
    }
}
