package Automotive;

public class Safari extends PV{
    String Carname;
    Double Price;
    public Safari(){

    }

    public Safari(String carname, Double price) {
        Carname = carname;
        Price = price;
    }
    @Override
    public void run() {
        System.out.println("This run function is override from PV"+ this.Price);
    }
}
