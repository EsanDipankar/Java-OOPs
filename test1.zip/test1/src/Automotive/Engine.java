package Automotive;

public interface Engine {
    public static int fan=1;
    public static int Engine_Oil=5;

    public abstract void run();

    public static void RunningNoice(){
        System.out.println("It is really very noicy");
    }


}
