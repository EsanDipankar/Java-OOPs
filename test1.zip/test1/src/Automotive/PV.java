package Automotive;

public class PV extends TataMotors implements Engine {
    @Override
    public void Production() {

    }

    @Override
    public void PlantHead() {

        super.PlantHead();
        Engine.RunningNoice();
    }

    @Override
    public void run() {
        System.out.println("This run function is defined in Engine Interface");
    }
}
