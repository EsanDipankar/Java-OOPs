public class Mamales extends Animal  {
    public int head;
    public int tail;

    protected Mamales(int i){
        super(i);
        //this();
    }
    protected Mamales(String sound){
        super(sound);
        //this();
    }
    protected Mamales(int head, int tail){
        super();
        this.head=head;
        this.tail=tail;
    }

}
