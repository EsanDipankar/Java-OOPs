package Human;

public abstract class ancistor {
    int memory;
    int leg;
    String power;
    public ancistor(int memory, int leg){
        this.memory=memory;
        this.leg= leg;

    }
    abstract void singing();

    public void dancing(){
        System.out.print("They are very good at dancing");
    }

}
