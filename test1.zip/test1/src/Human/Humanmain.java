package Human;

public class Humanmain extends ancistor {

    public Humanmain(int memory, int leg) {
        super(memory, leg);
    }

    @Override
    void singing() {
        System.out.println("The were a good singer");
    }

    //@Override
//    public void dancing() {
//        super.dancing();
//    }

    public static void main(String[] args){
        GrandParent gp = new Parent();
        gp.Teaching();
        PrivateTeacher pt;
        Parent parent = new Parent();
        GrandParent grandparent = new GrandParent();
        Humanity hum= new Humanity();
        hum.PropertyPrivateTeacher(gp);
        hum.PropertyPrivateTeacher(parent);
        hum.PropertyPrivateTeacher(grandparent);



    }
}
