package Human;

public class Parent extends GrandParent implements PrivateTeacher {
    String  Study;

    @Override
    public void Teaching() {
        PrivateTeacher.info();
        System.out.print("Private TEacher Intefrface is working");
    }

    public Parent() {
        super();
        PrivateTeacher.info();
    }
    static{
        //PrivateTeacher.info();
    }


}
