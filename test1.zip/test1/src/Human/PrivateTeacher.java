package Human;

public interface PrivateTeacher {
    public static int fees = 10000000;
    public static String name="Private Teacher";

    public abstract void Teaching();
    public static void info(){
        System.out.println("I am A Private Teacher with Fees " + fees );


    }
}
