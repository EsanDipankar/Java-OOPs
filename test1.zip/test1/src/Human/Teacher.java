package Human;

public interface Teacher {
}
