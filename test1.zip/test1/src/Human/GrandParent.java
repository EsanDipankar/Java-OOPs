package Human;

public class GrandParent implements PrivateTeacher {
    private int age;
    private String name;
    public void GrandParent(){
        System.out.println("I am a default Constructor of Grand Parent");
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void Teaching() {
        System.out.print("Grand parent also have private teacher");
    }


}
