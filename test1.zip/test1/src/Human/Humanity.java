package Human;

public class Humanity {
    public void PropertyPrivateTeacher(PrivateTeacher PT){
        int total= PT.fees;
        System.out.println("Total Fees is"+total );
    }
}
