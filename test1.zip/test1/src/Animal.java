public class Animal {
    public int leg;
    public String sound;

    public Animal(){
        leg=0;
        sound="";
        System.out.print("I am a Default constructor");
    }

    public Animal(int leg, String sound){
        this.leg= leg;
        this.sound= sound;
        System.out.print("I am a 2 Parameterized constructor");
    }

    public Animal(int leg){
        this();
        this.leg= leg;

        System.out.print("I am a 1 int Parameterized constructor");
    }

    protected Animal(String sound){
        this();
        this.sound= sound;
        System.out.print("I am a 1 String Parameterized constructor");
    }

}
