package com.dg.userService.UserService.repositories;

import com.dg.userService.UserService.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, String> {
    //
}
