package com.dg.userService.UserService.execption;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(){
        super("Resouces Not Found in the server !!");
    }
    public ResourceNotFoundException(String message){
        super(message);
    }
}
