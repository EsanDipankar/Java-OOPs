package com.dg.HotelService.HotelService.servises.impl;

import com.dg.HotelService.HotelService.entity.Hotel;
import com.dg.HotelService.HotelService.exception.ResouceNotFoundException;
import com.dg.HotelService.HotelService.repositories.HotelRepository;
import com.dg.HotelService.HotelService.servises.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class HotelServiceImpl implements HotelService {
    @Autowired
    private HotelRepository hotelRepository;
    @Override
    public Hotel createHotel(Hotel hotel) {
        String hotelId= UUID.randomUUID().toString();
        hotel.setId(hotelId);
        return hotelRepository.save(hotel);
    }

    @Override
    public List<Hotel> getAll() {
        return hotelRepository.findAll();
    }

    @Override
    public Hotel get(String id) {
        return hotelRepository.findById(id)
                .orElseThrow(() ->
                        new ResouceNotFoundException("Hotel with given id not found")
                );
    }

}
