package com.dg.HotelService.HotelService.repositories;

import com.dg.HotelService.HotelService.entity.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelRepository extends JpaRepository<Hotel , String> {
}
