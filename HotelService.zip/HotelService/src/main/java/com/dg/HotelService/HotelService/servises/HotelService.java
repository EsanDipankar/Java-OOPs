package com.dg.HotelService.HotelService.servises;

import com.dg.HotelService.HotelService.entity.Hotel;

import java.util.List;

public interface HotelService {
    //create
    Hotel createHotel(Hotel hotel);
    //getall
    List<Hotel> getAll();
    //getSingler
    Hotel get(String Id);

}
