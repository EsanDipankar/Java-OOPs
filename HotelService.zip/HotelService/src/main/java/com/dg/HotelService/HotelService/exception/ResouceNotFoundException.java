package com.dg.HotelService.HotelService.exception;

public class ResouceNotFoundException extends RuntimeException{
    public ResouceNotFoundException(String message){
        super(message);
    }

    public ResouceNotFoundException(){
        super("Resource Not Found !!");
    }
}
