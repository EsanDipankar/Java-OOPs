package com.dg.RatingService.RatingService.controllers;

import com.dg.RatingService.RatingService.entities.Rating;
import com.dg.RatingService.RatingService.repository.RatingRepository;
import com.dg.RatingService.RatingService.services.impl.RatingServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/ratings")
public class RatingController {
    @Autowired
    public RatingServiceImpl ratingService;


    @Autowired
    public RatingRepository ratingRepository;

    @PostMapping()
    public ResponseEntity<Rating> create(@RequestBody Rating rating){
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingService.createRating((rating)));
    }
    // get all by UserId
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Rating>> getRatingByUserId(@PathVariable String userId){
        return ResponseEntity.ok(ratingService.getallRatingByUserId(userId));
    }
    // get all by Hotel Id
    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Rating>> getRatingByHotelId(@PathVariable String hotelId){
        return ResponseEntity.ok(ratingService.getallRatingByHotelId(hotelId));
    }
    // get all by Rating Id
    @GetMapping("/hotels/{ratingId}")
    public ResponseEntity<List<Rating>> getRatingByRatingId(@PathVariable String ratingId){
        return ResponseEntity.ok(ratingService.getAllRatings());
    }


}
