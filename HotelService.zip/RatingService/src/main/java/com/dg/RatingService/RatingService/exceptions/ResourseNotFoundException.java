package com.dg.RatingService.RatingService.exceptions;

public class ResourseNotFoundException extends RuntimeException{
    public ResourseNotFoundException(){ super("User Not Found "); }
    public ResourseNotFoundException(String message){ super(message); }

}
