package com.dg.RatingService.RatingService.services;

import com.dg.RatingService.RatingService.entities.Rating;

import java.util.List;

public interface RatingService {
    // create
    Rating createRating(Rating rating);

    // get Rating By Id
    Rating getRatingById(String id);

    // get All rating
    List<Rating> getAllRatings();
    // get all by userId
    List<Rating> getallRatingByUserId(String userId);

    // getAll by hotel
    List<Rating> getallRatingByHotelId(String hotelId);
}
