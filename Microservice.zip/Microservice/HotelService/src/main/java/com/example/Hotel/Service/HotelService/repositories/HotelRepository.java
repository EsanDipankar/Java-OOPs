package com.example.Hotel.Service.HotelService.repositories;

import com.example.Hotel.Service.HotelService.entity.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HotelRepository extends JpaRepository<Hotel , String> {
}
