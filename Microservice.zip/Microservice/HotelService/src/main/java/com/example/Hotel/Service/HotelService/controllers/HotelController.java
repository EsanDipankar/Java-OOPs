package com.example.Hotel.Service.HotelService.controllers;

import com.example.Hotel.Service.HotelService.entity.Hotel;
import com.example.Hotel.Service.HotelService.servises.HotelService;
import com.example.Hotel.Service.HotelService.servises.impl.HotelServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotels")
public class HotelController {
    @Autowired
    public HotelServiceImpl hotelService;
    //  create
    @PostMapping
    public ResponseEntity<Hotel> createHotels(@RequestBody Hotel hotel){
        return ResponseEntity.status(HttpStatus.CREATED).body(hotelService.createHotel(hotel));
    }
    // get By Id
    @GetMapping("/{id}")
    public ResponseEntity<Hotel> getHotels(String id){
        return ResponseEntity.status(HttpStatus.OK).body(hotelService.get(id));
    }
    //  getAll
    @GetMapping
    public ResponseEntity<List<Hotel>> getAll(){
        return ResponseEntity.ok(hotelService.getAll());
    }

}
