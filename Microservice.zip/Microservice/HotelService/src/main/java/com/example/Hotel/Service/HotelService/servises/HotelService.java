package com.example.Hotel.Service.HotelService.servises;

import com.example.Hotel.Service.HotelService.entity.Hotel;

import java.util.List;

public interface HotelService {
    //create
    Hotel createHotel(Hotel hotel);
    //getall
    List<Hotel> getAll();
    //getSingler
    Hotel get(String Id);

}
