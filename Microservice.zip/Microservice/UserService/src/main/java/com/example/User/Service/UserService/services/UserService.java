package com.example.User.Service.UserService.services;

import com.example.User.Service.UserService.entities.User;

import java.util.List;

public interface UserService {
    // All the methods
    // create
    User SaveUser(User user);
    // GetAll user
    List<User> getAllUser();
    // getsingleUser
    User getUser(String userId);
    // Delete User
    String deleteUser(String userId);
    //update User
    User updateUser(User user);


}
